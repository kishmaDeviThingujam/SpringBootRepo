package com.mscript.customer.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerMapper implements RowMapper<Customer>
{
	@Override
	public Customer mapRow(ResultSet rs, int i) throws SQLException {
		
		Customer customer = new Customer();
		customer.setCustomerId(rs.getInt("customerId"));
		customer.setCustomerName(rs.getString("customerName"));
		customer.setCustomerAddress(rs.getString("customerAddress"));
		customer.setBillAmount(rs.getInt("billAmount"));
		return customer;
	}

}
