package com.mscript.customer.dao;

import java.util.List;

import com.mscript.customer.model.Customer;

public interface CustomerDAO {
		public boolean saveCustomer(Customer customer);
		public boolean deleteCustomer(int customerId);
		public boolean updateCustomer(int customerId,String newCustomerAddress,int newBillAmount);
		public Customer findCustomer(int customerId);
		public boolean isCustomerExists(int customerId);	
		public List<Customer> showCustomers();
}