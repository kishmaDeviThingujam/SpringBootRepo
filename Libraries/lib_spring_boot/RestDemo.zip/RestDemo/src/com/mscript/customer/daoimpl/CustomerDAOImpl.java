package com.mscript.customer.daoimpl;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.mscript.customer.dao.CustomerDAO;
import com.mscript.customer.model.Customer;
import com.mscript.customer.model.CustomerMapper;

public class CustomerDAOImpl implements CustomerDAO {

	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	
	@Override
	public boolean saveCustomer(Customer customer) {
		
		String query = "insert into customer values("+customer.getCustomerId()+",'"+customer.getCustomerName()+"','"+customer.getCustomerAddress()+"',"+customer.getBillAmount()+")";
		int i= jdbcTemplate.update(query);
		if(i==0)
			return false;
		else
			return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		String query = "delete from customer where customerId = "+customerId;
		
		return false;
	}

	@Override
	public boolean updateCustomer(int customerId, String newCustomerAddress,
			int newBillAmount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		String query = "select * from customer where customerId = "+customerId;
		return jdbcTemplate.queryForObject(query, new Object[] { customerId }, new CustomerMapper());

	}

	@Override
	public boolean isCustomerExists(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public List<Customer> showCustomers() {
		String query = "select * from customer";
		return jdbcTemplate.query(query, new CustomerMapper());
	}

}
