package com.mscript.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mscript.customer.dao.CustomerDAO;
import com.mscript.customer.model.Customer;

public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDAO customerDAO;
	
	
	@Override
	public boolean saveCustomer(Customer customer) {
		
		return customerDAO.saveCustomer(customer);
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateCustomer(int customerId, String newCustomerAddress,
			int newBillAmount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDAO.findCustomer(customerId);
	}

	@Override
	public boolean isCustomerExists(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Customer> showCustomers() {
		// TODO Auto-generated method stub
		return customerDAO.showCustomers();
	}

}
