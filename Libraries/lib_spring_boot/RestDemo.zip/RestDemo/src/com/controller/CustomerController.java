package com.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.mscript.customer.model.Customer;

@RestController
@EnableWebMvc
public class CustomerController {
	
	
	@RequestMapping(value = "/customer/" ,method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public  @ResponseBody ResponseEntity<Customer> getCustomerDetails()
    {
			Customer customer = new Customer();
			customer.setCustomerId(190);
			customer.setCustomerName("Tufail Ahmed");
			customer.setCustomerAddress("Jaipur");
			customer.setBillAmount(68000);
			return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}
	
	
}



