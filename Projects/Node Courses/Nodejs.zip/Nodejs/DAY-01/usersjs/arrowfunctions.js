// function sum(a,b)
// {
//     return a+b;
// }
// const sum=function(a,b)
// {

// }
const sum=(a,b)=>{
    return a+b;
};
