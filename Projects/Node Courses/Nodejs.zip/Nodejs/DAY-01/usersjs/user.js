const fs=require('fs');
let name='abc';
const userFileName='user.json'
function adduser(name,email)
{
    const users=loadusers();
    const newuser={
        name:name,
        email:email
    };
    users.push(newuser);
    saveusers(users);

    console.log("user added");
    
}
const listusers=function(){
    console.log('list of users');
    const user=loadusers();
    user.forEach(function(user)
{
    console.log('name:',user.name,'Email',user.email);
});
}
const readuser=function(name){
    const users=loadusers();
    const user=users.find(function(u)
{
    return u.name==name;
});
if(user){
    console.log('name:',user.name);
    console.log('Email',user.email);

}else{
    console.log('user not found')
}
}
const removeuser=function(){
    // console.log('lusers removed');
    // const userFileName='user.json'
    const users=loadusers();
    const filteredUsers=users.filter(function(u){
        return u.name!=name;
    });
    if(users.length>filteredUsers.length){
        saveusers(filteredUsers);
        console.log('users removed');
    }
    else{
        console.log("user not found");
    }
    
}
const saveusers=function(users){
const userString=JSON.stringify(users);
fs.writeFileSync(userFileName,userString);
}
const loadusers=function()
{
    try{
    const data=fs.readFileSync(userFileName);
    const userString=data.toString();
    const users=JSON.parse(userString);
    return users;
    }catch(e)
    {return[];}
}

module.exports={
    adduser:adduser,
    listusers:listusers,
    readuser:readuser,
    removeuser:removeuser
};