const yargs=require('yargs');
const users = require('./user')
//console.log('welcome app');
//console.log(adduser);
//adduser('abc','ghgfjhjh');
yargs.command
({command:'add',
desc:'Add User',
handler:function(argv){
    console.log();
    users.adduser(argv.name,argv.email);
},
builder:
{
    name:{
        desc:'user name',
        type:'String',
        demandOption:'true'
    },
    email:{
        desc: 'user email',
        type:'String',
        demandOption:'true'
    }
}
});
yargs.command
({command:'read',
desc:'Get User',
handler:function(argv){
    console.log();
    users.readuser(argv.name);
},
builder:
{
    name:{
        desc:'user name',
        type:'String',
        demandOption:'true'
    }
}
});
yargs.command
({command:'list',
desc:'list User',

handler:function(){
    users.listusers();
}
});
yargs.command
({command:'remove',
desc:'Remove User',
handler:function(argv){
    console.log();
    users.removeuser(argv.name);
},
builder:
{
    name:{
        desc:'user name',
        type:'String',
        demandOption:'true'
    }
}
});
yargs.parse();
//console.log(users.name);
// console.log(users.listusers);
// users.adduser('jay','abc');
// users.listusers('hari');
// users.readuser('hari');
// users.removeuser('hari');
