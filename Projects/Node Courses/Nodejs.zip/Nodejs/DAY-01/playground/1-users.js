console.log('begin')
const getuser=(id,callback)=>{
    setTimeout(()=>{
        callback({
            id,
            name:'krish',
            email:'krish@gmail.com'
        }
    );

    },3000);
    
}
const cbUser=(user)=>{
    console.log('user:',user);
}
const user=getuser(1,cbUser,);
console.log('user: ',user);
const sum=10+30;
console.log('sum',sum);
console.log('End')