let a=10;
{
    let a=20;
    console.log('inside block',a);
}
console.log('inside block',a);