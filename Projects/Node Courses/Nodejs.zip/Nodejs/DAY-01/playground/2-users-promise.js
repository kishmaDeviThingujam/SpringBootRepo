console.log('begin')
const getuser=(id)=>{
const p=new Promise((resolve,reject)=>{
    console.log('getting user...please wait!!!');
        setTimeout(()=>{
            resolve({
               id:id,
                name:'krish',
                email:'krish@gmail.com'
            }
        );
   // reject('unable to connect to server')
        },3000);
        
    
});
return p;
};
getuser(1)
.then((user)=>{
    console.log('then handler user',user);
    return getTodos(user.id)
})
.then((todos)=>{
    console.log('then hanler todos',todos);
})
.catch((error)=>{
    console.log('catch handler user',error);
});
const sum=10+30;
console.log('sum',sum);
console.log('End')