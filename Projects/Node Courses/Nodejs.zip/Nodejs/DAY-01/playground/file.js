const fs=require('fs')
// fs.writeFileSync('text.txt','fssdhtdjyfkgk')
//fs.FileSynppendc('text.txt','fssdhtdjyfkgk');
// const data=fs.readFileSync('text.txt');
// console.log(data.toString());
//converting to json
// const user={
//     name:'abc',
//     email:'abc@gmail'
// };
// const userstr=JSON.stringify(user);
// fs.writeFileSync('user.json',userstr)
//reverse getting the js object

//es6
display()
{}

const data=fs.readFileSync('user.json');
const userstr=data.toString;