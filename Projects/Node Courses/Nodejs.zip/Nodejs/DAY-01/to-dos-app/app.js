const express=require('express');
const path=require('path');
const api=require('./src/api');
const app=express();
console.log(__dirname);
//const publicpath=__dirname+'/public';
//const publicpath=`${__dirname}\\public`;
const publicpath=path.join(__dirname,'public');
console.log(publicpath);
app.use(express.static(publicpath));
//http://localhost:3000
app.get('',(req,res)=>{
   // res.send('welcome to express');
   res.render('index',
{
    title:'todo list'
});
});
app.get('/hey',(req,res)=>{
    res.send('<h2>hey hello world</h2>');
});
app.get('/go',(req,res)=>{
    res.send('lets go');
});
app.get('/todos',(req,res)=>{
    console.log(req.params);
    const username=req.query;
    let user1={};
api.getUser('Bret',(error,user)=>{
  if(error) {
      return console.log('error:',error)
  }
  console.log('user:',user);
  user1=user;
});
api.getUser('aa',(error,user)=>{
    if(error) {
        return console.log('error:',error)
    }
    console.log('user:',user);

    api.getTodos(user1.id,(error,todos)=>{
        if(error) {
            return console.log('error:',error)
        }
        const data={
            user,
            todos
        };
        res.json(data);
      });
  }); 
});


// // app.post();
// // app.patch();
// // app.delete();
app.get('/todos/:id');

app.listen(3000,()=>{
    console.log('your app is started and available on port 3000');
});

// let user1={};
// api.getUser('bret',(error,user)=>{
//   if(error) {
//       return console.log('error:',error)
//   }
//   console.log('user:',user);
//   user1=user;
// });
// api.getUser('aa',(error,user)=>{
//     if(error) {
//         return console.log('error:',error)
//     }
//     console.log('user:',user);

//     api.getTodos(user1.id,(error,todos)=>{
//         if(error) {
//             return console.log('error:',error)
//         }
//         console.log('todos:',todos);
//       });
//   });
 