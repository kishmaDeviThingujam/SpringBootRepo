const request=require('request');
const userurl='https://jsonplaceholder.typicode.com/users?user?username=Bert';
const baseurl='https://jsonplaceholder.typicode.com';
const getUser=(username,callback)=>{
    //const url=baseurl+'/users?username='+username
const url=`${baseurl}/users?username=${username}`;
request({ url:userurl,json:true},(error,response)=>
{
    // console.log('error',error);
    // console.log('success',response.body);
     if(error){
        return callback('unable to access the service');
    }
    if(!response.body[0]){
        return ceallback('user not present');
        return

    }

const user={
    id:response.body[0].id,
    name:response.body[0].name
};
callback('undefined',user);
});


};
const getTodos=(userID,callback)=>{
    const url=`${baseurl}/todos?userId=${userId}`;
request({ url,json:true},(error,response)=>
{
    // console.log('error',error);
    // console.log('success',response.body);
     if(error){
        return callback('unable to access the service');
    }
    if(!response.body.length==0){
        return callback('todos not available');
       

    }

const user={
    id:response.body[0].id,
    name:response.body[0].name
};
callback('TODO',todos);
});


};
module.exports={getUser,getTodos};
