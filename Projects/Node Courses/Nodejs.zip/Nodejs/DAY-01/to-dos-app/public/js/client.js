console.log('client.js is shown');
const uname=document.getElementById('username');
console.log(uname.value);const formElement=document.querySelector('form');
formElement.addEventListener('submit',(e)=>{
    e.preventDefault
    const username=uname.value;
});
