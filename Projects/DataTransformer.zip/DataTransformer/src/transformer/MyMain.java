package transformer;

public class MyMain {

	public static void main(String[] args) {
		IPatientReviewReader reader1	=new PatientReviewCSVReader("C://user//demo");
		IPatientReviewDAO writer=new MySQLPatientReviewDAO();
		PatientReviewDataTransformer patientReviewDataTransformer=new PatientReviewDataTransformer();		
		IPatientReviewReader reader2=new PatientReviewXMLReader("C://user//demo");
		patientReviewDataTransformer.transform(reader1, writer);

	}

}
