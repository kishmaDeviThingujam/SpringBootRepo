package transformer;

public class PatientReviewModel {
private String hostpitalName;
private String patientName;
private String review;
public String getHostpitalName() {
	return hostpitalName;
}
public void setHostpitalName(String hostpitalName) {
	this.hostpitalName = hostpitalName;
}
public String getPatientName() {
	return patientName;
}
public void setPatientName(String patientName) {
	this.patientName = patientName;
}
public String getReview() {
	return review;
}
public void setReview(String review) {
	this.review = review;
}

}
