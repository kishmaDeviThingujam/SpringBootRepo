package transformer;

import java.util.ArrayList;

public interface IPatientReviewReader {
	public ArrayList<PatientReviewModel> getAllpatientReviews();
	

}
