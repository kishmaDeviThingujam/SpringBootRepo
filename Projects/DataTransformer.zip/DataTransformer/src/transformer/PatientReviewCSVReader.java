package transformer;

import java.util.ArrayList;

public class PatientReviewCSVReader implements IPatientReviewReader{
	private String filepath;
	
public PatientReviewCSVReader(String filepath) {
		super();
		this.filepath = filepath;
	}

public ArrayList<PatientReviewModel> getAllpatientReviews()
{
	return null;
}
}
