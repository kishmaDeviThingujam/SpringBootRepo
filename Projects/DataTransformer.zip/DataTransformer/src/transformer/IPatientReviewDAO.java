package transformer;

import java.util.ArrayList;

public interface IPatientReviewDAO {
	public  void saveAll(ArrayList<PatientReviewModel> patientReviewList);
}
