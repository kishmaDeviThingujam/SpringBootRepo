package transformer;

import java.util.ArrayList;

public class PatientReviewXMLReader implements IPatientReviewReader{
	private String filepath;
	
	public PatientReviewXMLReader(String filepath) {
			super();
			this.filepath = filepath;
		}

	public ArrayList<PatientReviewModel> getAllpatientReviews()
	{
		return null;
	}
}
