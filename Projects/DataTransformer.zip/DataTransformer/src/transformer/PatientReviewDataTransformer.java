package transformer;

import java.util.ArrayList;

public class PatientReviewDataTransformer {
public void transform(IPatientReviewReader patientReviewReader,IPatientReviewDAO PatientReviewDAO )
{
	ArrayList<PatientReviewModel> records=patientReviewReader.getAllpatientReviews();
	PatientReviewDAO.saveAll(records);
}

}
